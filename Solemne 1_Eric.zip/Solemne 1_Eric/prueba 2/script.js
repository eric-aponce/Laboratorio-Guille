// =============================
const width = 700;
const height = 800;
const radius = 300;


const svg = d3.select("#chart")
  .attr("width", width)
  .attr("height", height);

const g = svg.append("g")
  .attr("transform", `translate(${width / 2}, ${height - 100})`);

// Tooltip
const tooltip = d3.select("#tooltip");

// CARGA DE DATOS DESDE CSV
d3.csv("Coffe_sales.csv").then(data => {
  const counts = d3.rollup(data, v => v.length, d => d.coffee_name);
  const dataset = Array.from(counts, ([name, value]) => ({ name, value }));

  // Escalas
  const angle = d3.scaleBand()
    .domain(dataset.map(d => d.name))
    .range([Math.PI, 2 * Math.PI])
    .padding(0.05);

  const radiusScale = d3.scaleLinear()
    .domain([0, d3.max(dataset, d => d.value)])
    .range([0, radius]);

// Dibujar barras radiales
  g.selectAll("path")
    .data(dataset)
    .enter()
    .append("path")
    .attr("fill", "#8b4513")
    .attr("d", d => {
      const startAngle = angle(d.name);
      const endAngle = startAngle + angle.bandwidth();
      const r = radiusScale(d.value);

      const arc = d3.arc()
        .innerRadius(0)
        .outerRadius(r)
        .startAngle(startAngle)
        .endAngle(endAngle);

      return arc();
    })
    // === Eventos tooltip ===
    .on("mouseover", function(event, d) {
      tooltip
        .style("opacity", 1)
        .html(`<b>${d.name}</b><br>Cafés vendidos: ${d.value}`);
    })
    .on("mousemove", function(event) {
      tooltip
        .style("left", (event.pageX + 10) + "px")
        .style("top", (event.pageY - 20) + "px");
    })
    .on("mouseout", function() {
      tooltip.style("opacity", 0);
    });

  // Etiquetas
  g.selectAll(".label")
    .data(dataset)
    .enter()
    .append("text")
    .attr("class", "label")
    .attr("transform", d => {
      const a = angle(d.name) + angle.bandwidth() / 2;
      const r = radius + 20;
      return `translate(${Math.cos(a) * r}, ${Math.sin(a) * r})`;
    })
    .text(d => d.name);
});