//VARIABLES GLOBALES
const width = 700; /* ancho*/
const height = 800; /* alto*/
const radius = 300; /* radio max bordes radial*/

//SELECCIONA SVG EN HTML
const svg = d3.select("#chart")
    .attr('width', width) /*ancho*/
    .attr('height', height) /*alto*/

//SEMI-CÍRCULO
const g = svg.append('g')
    .attr('transform', `translate(${width / 2}, ${height - 400})`); /*centrado*/

//TOOLTIP
const tooltip = d3.select("#tooltip") 

//CARGA DATOS
d3.csv('Coffe_sales.csv').then(data => { 
    const counts = d3.rollup(data, v => v.length, d => d.coffee_name); /*Cuenta cafe segú tipo*/
    const dataset = Array.from(counts, ([name, value]) => ({ name, value })); /*convierte en objeto*/

//ESCALA NOMBRE CAFÉ
const angle = d3.scaleBand()
    .domain(dataset.map(d => d.name))
    .range([Math.PI, 2 * Math.PI])
    .padding(0.05);

  const radiusScale = d3.scaleLinear()
    .domain([0, d3.max(dataset, d => d.value)])
    .range([0, radius]);

//ESCALA VALOR VENTAS
g.selectAll("path") /*selecciona las barras*/
    .data(dataset) /*datos*/
    .enter()
    .append("path") /*agrega las barras*/
    .attr("fill", "#8b4513") /*color barras*/
    .attr("d", d => {
        const starAngle = angle(d.name); /*inicial angulo*/
        const endAngle = starAngle + angle.bandwidth(); /*angulo final*/
        const r = radiusScale(d.value); /*tamaño radio segun valor*/

        //ARCO
        const arc = d3.arc() /*arco*/
            .innerRadius(0) /*radio interno*/
            .outerRadius(r) /*radio externo*/
            .startAngle(starAngle) /*inicial angulo*/
            .endAngle(endAngle); /*final angulo*/
     return arc();
    })

//MOUSE
    .on("mouseover", function(event, d) { 
        tooltip
            .style("opacity", 1) /*opacidad*/
            .html(`<b>${d.name}</b><br>Cafés vendidos: ${d.value}`); /*info*/
    })
    .on("mousemove", function(event) {
        tooltip
            .style("left", (event.pageX + 10) + "px") /*posicion Y*/
            .style("top", (event.pageY - 20) + "px") /*posicion X*/
    })
    .on("mouseout", function() {
        tooltip.style("opacity", 0); /*opacidad*/
    })
//ETIQUETAS
    g.selectAll("label") /*selecciona texto*/
        .data(dataset) /*datos*/
        .enter()
        .append("text") /*agrega texto*/
        .attr("class", "label") /*centrado*/
        .attr("transform", d => {
            const a = angle(d.name) + angle.bandwidth() /2;
            const r = radius (d.value) + 20;
            return `translate(${Math.cos(a) * r}, ${Math.sin(a) * r})`; /*posicion*/
        })
        .text(d => d.name); /*text*/
    });
    